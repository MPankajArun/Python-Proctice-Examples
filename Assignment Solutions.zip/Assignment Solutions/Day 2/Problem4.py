keys=['red','green','blue']
values=['#FF0000','#008000','#0000FF']
color_dictionary ={}
result = zip(keys,values)
print dict(result)

