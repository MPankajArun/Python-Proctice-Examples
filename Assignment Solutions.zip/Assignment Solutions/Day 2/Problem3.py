def printValues():
    headList = [i**2 for i in range(1,6)]
    tailList = [i**2 for i in range(25,31)]
    print headList
    print tailList

printValues()
