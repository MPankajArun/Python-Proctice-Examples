num = [22,4,54,576,33]
print "Largest Element : ",max(num)
