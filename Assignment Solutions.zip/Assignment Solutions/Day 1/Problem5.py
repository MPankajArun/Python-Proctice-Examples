num = [10,45,34,88]
print sum(num)
