unsortedList = ['Aaaa', 'bb', 'cccccccc', 'zzzzzzzzzzzz']
print "Unsorted List : " ,unsortedList
sortedList = sorted(unsortedList,key=len)
print "Sorted List : " ,sortedList
