num1 = input("Enter the First Number : ")
num2 = input("Enter the Second Number : ")

print "Addition of %s and %s is : " %(num1,num2),num1+num2
print "Substraction of %s and %s is : " %(num1,num2),num1-num2
