str1 = raw_input("Enter the string : ")
rev = str1[::-1]
if str1==rev:
    print "%s is Palindrome" %str1
else:
    print "%s is not Palindrome" %str1
